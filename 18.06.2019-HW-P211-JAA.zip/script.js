"use strict";
const bubleZone = document.getElementsByClassName("bubleZone")[0];
const buble = document.getElementsByClassName("buble")[0];
const color = document.getElementById("color");
const myBackgraundColor = document.getElementById("backgraundColor");
const picture = document.getElementById("picture");
const backgroundPicture = document.getElementById("backgroundPicture");
const rarius = document.getElementById("rarius");
const speed = document.getElementById("speed");

color.onchange = () => {
  buble.style.backgroundColor = color.value;
};
myBackgraundColor.onchange = () => {
  bubleZone.style.backgroundColor = myBackgraundColor.value;
};
picture.oninput = () => {
  const img = document.createElement("img");
  img.setAttribute("src", picture.value);
  buble.appendChild(img);
};
backgroundPicture.oninput = () => {
  const bgimg = document.createElement("img");
  bgimg.setAttribute("src", backgroundPicture.value);
  bubleZone.appendChild(bgimg);
};

radius.onchange = () => {
  buble.style.width = radius.value +"px";
  buble.style.height = radius.value +"px";
};

speed.onchange = () => {
  buble.style.animationName = "buble";
  buble.style.animationDuration = speed.value + "s";
  buble.style.animationDirection = "alternate-reverse";
  buble.style.animationIterationCount = "infinite";
  buble.style.animationTimingFunction = "linears";
};
